README

All images in this project could be found at google.com .
This project was made for BIM_222 coded INTERNET PROGRAMMING course Homework 2. 

I made this project all of my love and my sweat. I hope it's come out good.

This project was made by Mert Can KALINLIOĞLU, studen ID' 12331354158.

2024